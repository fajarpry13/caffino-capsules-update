<?

phpinfo();